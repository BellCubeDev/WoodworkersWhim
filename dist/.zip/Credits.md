# Contributors to Linear Spell Progression

Up here live those who have contributed the absolute most to the project

## Discord User *Skel Maxim*

The person who originally suggested the idea of this project.

## [PistachioRaptor](https://nexusmods.com/users/7101768) & [rux616](https://nexusmods.com/users/124191)

**Invaluable** insight into improvements for my code
